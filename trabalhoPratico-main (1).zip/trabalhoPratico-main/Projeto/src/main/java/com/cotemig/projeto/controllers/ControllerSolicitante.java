package com.cotemig.projeto.controllers;

public class ControllerSolicitante {
}
