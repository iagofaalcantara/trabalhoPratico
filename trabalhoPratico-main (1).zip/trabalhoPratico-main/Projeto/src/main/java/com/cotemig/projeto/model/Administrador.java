package com.cotemig.projeto.model;

public class Administrador extends Usuario{
    public Administrador(String nome, String email, String senha, String setor, int ramal, String cargo) {
        super(nome, email, senha, setor, ramal, cargo);
    }
}
