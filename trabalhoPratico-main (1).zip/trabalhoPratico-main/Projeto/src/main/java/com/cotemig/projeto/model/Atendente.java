package com.cotemig.projeto.model;

public class Atendente extends Usuario{
    public Atendente(String nome, String email, String senha, String setor, int ramal, String cargo) {
        super(nome, email, senha, setor, ramal, cargo);
    }
}
