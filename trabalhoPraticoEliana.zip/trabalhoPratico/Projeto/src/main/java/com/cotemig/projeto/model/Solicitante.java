package com.cotemig.projeto.model;

public class Solicitante extends Usuario{
    public Solicitante(String nome, String email, String senha, String setor, int ramal, String cargo) {
        super(nome, email, senha, setor, ramal, cargo);
    }
}
