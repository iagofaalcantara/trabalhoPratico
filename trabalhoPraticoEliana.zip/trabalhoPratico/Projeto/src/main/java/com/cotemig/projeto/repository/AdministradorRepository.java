package com.cotemig.projeto.repository;

public interface AdministradorRepository {
}
