package com.cotemig.projeto.repository;

public interface SolicitanteRepository {
}
