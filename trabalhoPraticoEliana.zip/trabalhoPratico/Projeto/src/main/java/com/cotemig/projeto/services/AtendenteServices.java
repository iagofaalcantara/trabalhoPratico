package com.cotemig.projeto.services;

public class AtendenteServices {
}
